from pydub import AudioSegment
from io import BytesIO
from pydub.silence import split_on_silence
import base64
import os
import sys
import boto3

s3_client = boto3.client('s3')

def lambda_handler(event, context):

    #TODO: How do we get the file into Lambda
    print('OK function start')
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key'] 
        download_path = '/tmp/{}{}'.format('file', key)
        print(download_path)
        s3_client.download_file(bucket, key, download_path)
       
    return 'Hello from Lambda deploy' + key
